package com.example.demo.repositoriess;

import java.util.List;

import com.example.demo.Student;

public interface StudentRepositoryCustom 
{
	//List<Student> getAllStudents();
}
