package com.example.demo;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


import table.Teacher;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

	
	/* @Before
	  public void setUp() throws Exception {
	      Teacher teacher1 = new Teacher("A", "k", "ak152", "4589632");
	    		  
	        //save user, verify has ID value after save
	        this.teacherRepo.save(teacher1);
	    }*/


	@Test
	public void contextLoads() {
	}

}
